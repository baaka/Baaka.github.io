// Quiz questions with developer humor
const questions = [
  {
    question: "It's 3 AM and your code isn't working. What do you do?",
    answers: [
      { text: "Add more console.log() statements! 🔍", type: "debugger" },
      {
        text: "Google the error message for the 100th time 🔎",
        type: "googler",
      },
      { text: "Rewrite everything from scratch! 🔥", type: "architect" },
      { text: "Take a break and come back fresh ☕", type: "zen" },
    ],
  },
  {
    question: "Your favorite way to learn a new technology?",
    answers: [
      { text: "Read the entire documentation first 📚", type: "architect" },
      { text: "Jump right in and break things! 💥", type: "hacker" },
      { text: "Follow tutorials step by step 📝", type: "googler" },
      { text: "Build a real project immediately 🚀", type: "builder" },
    ],
  },
  {
    question: "How do you feel about CSS?",
    answers: [
      { text: "I love making things beautiful! 🎨", type: "designer" },
      { text: "It's a necessary evil 😅", type: "backend" },
      { text: "Flexbox? Grid? I know them all! 💪", type: "frontend" },
      { text: "I just use a framework 🛠️", type: "pragmatic" },
    ],
  },
  {
    question: "Your code review style?",
    answers: [
      { text: "Nitpick every detail! 🔬", type: "perfectionist" },
      { text: "If it works, ship it! 🚢", type: "pragmatic" },
      { text: "Suggest improvements kindly 😊", type: "mentor" },
      { text: "Focus on architecture and patterns 🏗️", type: "architect" },
    ],
  },
  {
    question: "When do you commit your code?",
    answers: [
      { text: "After every small change ✅", type: "organized" },
      { text: "When it finally works! 🎉", type: "hacker" },
      {
        text: "Following a strict commit message convention 📋",
        type: "professional",
      },
      { text: "What's a commit? I just push to main 😈", type: "chaotic" },
    ],
  },
];

// Developer personality types
const personalities = {
  debugger: {
    emoji: "🔍",
    title: "The Detective Developer",
    description:
      "You love solving mysteries! Every bug is a puzzle waiting to be solved. You're patient, methodical, and won't rest until you find the root cause. Console.log is your best friend!",
    traits: ["Analytical", "Patient", "Detail-oriented", "Problem-solver"],
  },
  googler: {
    emoji: "🔎",
    title: "The Stack Overflow Sage",
    description:
      "You know that every problem has been solved before! You're a master at finding solutions online and adapting them to your needs. Your browser history is 90% Stack Overflow.",
    traits: ["Resourceful", "Practical", "Quick learner", "Community-driven"],
  },
  architect: {
    emoji: "🏗️",
    title: "The Code Architect",
    description:
      "You think big picture! Before writing a single line of code, you plan the entire structure. Design patterns are your poetry, and clean architecture is your art.",
    traits: ["Strategic", "Organized", "Forward-thinking", "Perfectionist"],
  },
  zen: {
    emoji: "🧘",
    title: "The Zen Coder",
    description:
      "You understand that the best code is written with a clear mind. You take breaks, practice self-care, and know that stepping away often leads to the best solutions.",
    traits: ["Balanced", "Wise", "Patient", "Sustainable"],
  },
  hacker: {
    emoji: "💻",
    title: "The Fearless Hacker",
    description:
      "You learn by doing and breaking things! Trial and error is your method. You're not afraid to experiment, and you often discover creative solutions others miss.",
    traits: ["Adventurous", "Creative", "Bold", "Experimental"],
  },
  builder: {
    emoji: "🚀",
    title: "The Rapid Builder",
    description:
      "You're all about shipping! You learn best by building real projects. MVPs are your specialty, and you can turn ideas into working prototypes faster than anyone.",
    traits: ["Action-oriented", "Productive", "Pragmatic", "Fast learner"],
  },
  designer: {
    emoji: "🎨",
    title: "The Design-Minded Developer",
    description:
      "You care deeply about user experience and aesthetics! Your code not only works but looks beautiful. You understand that great design is just as important as great code.",
    traits: ["Creative", "User-focused", "Aesthetic", "Empathetic"],
  },
  backend: {
    emoji: "⚙️",
    title: "The Backend Wizard",
    description:
      "You love the logic and systems behind the scenes! Databases, APIs, and server architecture are your playground. The frontend? That's someone else's problem!",
    traits: ["Logical", "Systematic", "Efficient", "Infrastructure-focused"],
  },
  frontend: {
    emoji: "✨",
    title: "The Frontend Maestro",
    description:
      "You make the web beautiful and interactive! You know every CSS trick and JavaScript framework. Your passion is creating amazing user experiences.",
    traits: ["Creative", "Detail-oriented", "User-focused", "Modern"],
  },
  pragmatic: {
    emoji: "🛠️",
    title: "The Pragmatic Programmer",
    description:
      "You focus on what works! You're not interested in perfect code, just code that solves the problem efficiently. You ship features while others are still debating patterns.",
    traits: ["Practical", "Efficient", "Results-driven", "Flexible"],
  },
  perfectionist: {
    emoji: "💎",
    title: "The Code Perfectionist",
    description:
      "Every line of code must be perfect! You refactor religiously, write comprehensive tests, and your code reviews are legendary. Quality over speed, always.",
    traits: ["Meticulous", "Quality-focused", "Thorough", "Professional"],
  },
  mentor: {
    emoji: "🌟",
    title: "The Mentor Developer",
    description:
      "You love helping others grow! You're patient, encouraging, and always willing to explain concepts. You believe that lifting others up makes the whole team stronger.",
    traits: ["Supportive", "Patient", "Communicative", "Team-player"],
  },
  organized: {
    emoji: "📊",
    title: "The Organized Developer",
    description:
      "Everything has its place! Your commits are atomic, your branches are named perfectly, and your code is always well-documented. Chaos is your enemy.",
    traits: ["Systematic", "Disciplined", "Reliable", "Professional"],
  },
  professional: {
    emoji: "👔",
    title: "The Professional Developer",
    description:
      "You follow best practices religiously! Conventions, standards, and proper procedures are important to you. Your code is enterprise-ready from day one.",
    traits: ["Disciplined", "Reliable", "Standards-focused", "Consistent"],
  },
  chaotic: {
    emoji: "🌪️",
    title: "The Chaotic Coder",
    description:
      "You thrive in chaos! Your methods may seem unconventional, but somehow you get things done. You're the wild card that every team secretly needs.",
    traits: ["Unpredictable", "Creative", "Bold", "Unconventional"],
  },
};

// Fun facts about programming
const funFacts = [
  "The first computer bug was an actual bug - a moth found in a computer in 1947! 🦋",
  "The first programmer was Ada Lovelace in the 1840s, before computers even existed! 👩‍💻",
  "JavaScript was created in just 10 days by Brendan Eich in 1995! ⚡",
  "The average developer makes 15-50 mistakes per 1000 lines of code! 🐛",
  "Programmers spend about 75% of their time debugging and only 25% writing new code! 🔍",
  "The term 'debugging' was popularized by Grace Hopper in the 1940s! 🔧",
  "There are over 700 programming languages in existence! 🌍",
  "The first computer programmer was a woman - Ada Lovelace! 🌟",
];

// State
let currentQuestion = 0;
let answers = [];
let selectedAnswer = null;

// DOM Elements
const questionNumber = document.getElementById("questionNumber");
const questionText = document.getElementById("questionText");
const answersGrid = document.getElementById("answersGrid");
const nextButton = document.getElementById("nextButton");
const progressFill = document.getElementById("progressFill");
const questionSection = document.getElementById("questionSection");
const resultSection = document.getElementById("resultSection");
const funFactText = document.getElementById("funFactText");

// Initialize quiz
function initQuiz() {
  currentQuestion = 0;
  answers = [];
  selectedAnswer = null;
  showQuestion();
  showRandomFunFact();
}

// Show current question
function showQuestion() {
  const question = questions[currentQuestion];

  // Update progress
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  progressFill.style.width = `${progress}%`;

  // Update question number and text
  questionNumber.textContent = `Question ${currentQuestion + 1} of ${
    questions.length
  }`;
  questionText.textContent = question.question;

  // Clear and populate answers
  answersGrid.innerHTML = "";
  question.answers.forEach((answer, index) => {
    const button = document.createElement("button");
    button.className = "answer-button";
    button.textContent = answer.text;
    button.onclick = () => selectAnswer(index);
    answersGrid.appendChild(button);
  });

  // Hide next button
  nextButton.style.display = "none";
  selectedAnswer = null;
}

// Select an answer
function selectAnswer(index) {
  selectedAnswer = index;

  // Update button styles
  const buttons = answersGrid.querySelectorAll(".answer-button");
  buttons.forEach((btn, i) => {
    if (i === index) {
      btn.classList.add("selected");
    } else {
      btn.classList.remove("selected");
    }
  });

  // Show next button
  nextButton.style.display = "block";
}

// Go to next question
function nextQuestion() {
  if (selectedAnswer === null) return;

  // Save answer
  answers.push(questions[currentQuestion].answers[selectedAnswer].type);

  // Move to next question or show results
  currentQuestion++;
  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    showResults();
  }
}

// Calculate and show results
function showResults() {
  // Count answer types
  const typeCounts = {};
  answers.forEach((type) => {
    typeCounts[type] = (typeCounts[type] || 0) + 1;
  });

  // Find most common type
  let maxCount = 0;
  let resultType = "pragmatic"; // default
  for (const [type, count] of Object.entries(typeCounts)) {
    if (count > maxCount) {
      maxCount = count;
      resultType = type;
    }
  }

  // Get personality
  const personality = personalities[resultType] || personalities.pragmatic;

  // Hide question section, show result section
  questionSection.style.display = "none";
  resultSection.style.display = "block";

  // Populate results
  document.getElementById("resultEmoji").textContent = personality.emoji;
  document.getElementById("resultTitle").textContent = personality.title;
  document.getElementById("resultDescription").textContent =
    personality.description;

  // Add trait badges
  const traitsContainer = document.getElementById("resultTraits");
  traitsContainer.innerHTML = "";
  personality.traits.forEach((trait) => {
    const badge = document.createElement("span");
    badge.className = "trait-badge";
    badge.textContent = trait;
    traitsContainer.appendChild(badge);
  });
}

// Restart quiz
function restartQuiz() {
  questionSection.style.display = "block";
  resultSection.style.display = "none";
  initQuiz();
}

// Share result
function shareResult(platform) {
  const resultTitle = document.getElementById("resultTitle").textContent;
  const text = `I just took the Developer Personality Quiz and I'm ${resultTitle}! 🎮`;

  if (platform === "twitter") {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
      text
    )}`;
    window.open(url, "_blank");
  } else if (platform === "copy") {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        alert("Result copied to clipboard! 📋");
      })
      .catch(() => {
        alert("Could not copy to clipboard 😅");
      });
  }
}

// Show random fun fact
function showRandomFunFact() {
  const randomFact = funFacts[Math.floor(Math.random() * funFacts.length)];
  funFactText.textContent = randomFact;
}

// Event Listeners
nextButton.addEventListener("click", nextQuestion);
document.getElementById("restartButton").addEventListener("click", restartQuiz);

// Change fun fact every 10 seconds
setInterval(showRandomFunFact, 10000);

// Initialize on load
window.addEventListener("load", initQuiz);
